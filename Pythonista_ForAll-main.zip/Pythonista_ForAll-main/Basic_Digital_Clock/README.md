# Basic_Digital_Clock
This is a basic digital clock which displays time in HH:MM:SS format.
