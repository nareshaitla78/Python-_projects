# Image_Compressor
This is an image compressor project. We have to upload an image file from a local drive and it compresses the size of the image. Note: The image file should be in the project folder.
