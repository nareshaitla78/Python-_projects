# Image_Cartoonization
This project is image cartoonization. We upload an image from a local drive and it cartoonizes it. Note: The image file should be in the project folder.
