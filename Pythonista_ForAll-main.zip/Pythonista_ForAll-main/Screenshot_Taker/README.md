# Screenshot_Taker
This project helps you in taking the screenshot of the page you are in.
