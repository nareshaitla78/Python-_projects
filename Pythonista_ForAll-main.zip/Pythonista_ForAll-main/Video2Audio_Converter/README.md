# Video2Audio_Converter
This project converts video into an audio file. 
When you run it, you get an option to select a video file and it converts automatically into an audio format.
Note: The video file should be present in the project folder.
