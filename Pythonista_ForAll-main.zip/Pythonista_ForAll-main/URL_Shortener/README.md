# URL_Shortener
This project helps in shortening your url into a customized one.
Enter your URL in "My URL Shortner" and click an option of "Generate Short Url". It generates the customized URL and displays in the allotted space.
You can copy the URL using "Copy URL" button

# Screenshot

![URL Shortener](https://github.com/prathimacode-hub/Pythonista_ForAll/blob/main/URL_Shortener/URL%20Shortener%20Screenshot.png)
