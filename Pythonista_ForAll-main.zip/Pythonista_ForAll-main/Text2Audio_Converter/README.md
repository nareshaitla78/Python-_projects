# Text2Audio
This project reads the text file(any document or pdf) in an audio format. You have to give file name of the document you want to read it for you in the code. Note : Doc or PDF file should be in the project folder.
